import React from "react";
import { useNavigate } from "react-router-dom";
import { getLaptopHeader, getLaptop } from "../api/laptopApi.js";
import OpenModal from "../components/OpenModal.jsx";
import ProductCard from "../components/ProductCard";

const LaptopDeals = () => {
  const iphoneCats = getLaptopHeader();
  const trendingDeals = getLaptop('hp').concat(getLaptop('dell')).concat(getLaptop('lenovo'));
  const navigate = useNavigate();

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  return (
    <>
      <div className="text-center bg-white mt-4 mb-4 rounded-md shadow-md p-4 text-xl font-semibold">
        Laptop Deals
      </div>

      <section
        className="bg-gray-100 container mx-auto mb-4 p-4 rounded-md shadow-md"
        onLoad={scrollToTop}
      >
        <OfficialStore
          categories={iphoneCats.map(({ id, img }) => ({ id, img, name: '' }))}
          onCategoryClick={(id) => {
            navigate(`/laptop-deals/${id}`);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        />
      </section>

      {/* Trending Deals */}
      <section className="container mx-auto p-4 rounded-md shadow-md bg-white">
        <div className="text-2xl text-center font-bold text-yellow-600 mb-4 uppercase">
          Some Trending Deals
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          {trendingDeals.map((trendingDeal) => {
            const { name, id, image, price } = trendingDeal;

            return (
              <OpenModal
                key={id}
                laptopinfoid={id}
                className="block mt-2"
                onClick={() => {
                  scrollToTop();
                }}
              >
                <ProductCard product={{ image, name, price }} />
              </OpenModal>
            );
          })}
        </div>
      </section>
    </>
  );
};

export default LaptopDeals;
