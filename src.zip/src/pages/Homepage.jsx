import React from 'react';
import { Link } from 'react-router-dom';
import Footer from '../components/Footer';
import banner1 from '../assets/img/OTW-340-1920820.png';
import banner2 from '../assets/img/freepik-export-20240803150659TGc0.png';
import banner3 from '../assets/img/freepik-export-202408031523174eMe.png';
import banner4 from '../assets/img/banner-l1.png';
import banner5 from '../assets/img/freepik-export-20240803152820errY.png';
import banner6 from '../assets/img/smartwatch-banner.png';

import dealPhone from '../assets/img/Artboard_1_copy_2.png';
import dealLaptop from '../assets/img/Artboard_1_copy_3.png';
import dealPowerbank from '../assets/img/Powerbank-1.jpg';
import dealHeadphone from '../assets/img/Headphone-1.jpg';
import dealSpeaker from '../assets/img/Portable_speaker-1.jpg';
import dealCharger from '../assets/img/Phone_charger-1.jpg';
import dealSmartwatch from '../assets/img/Smartwatch-1.jpg';
import dealFlashdrive from '../assets/img/clipper.jpg';

const banners = [
  { src: banner1, alt: 'Banner 1' },
  { src: banner2, alt: 'Banner 2' },
  { src: banner3, alt: 'Banner 3' },
  { src: banner4, alt: 'Banner 4' },
  { src: banner5, alt: 'Banner 5' },
  { src: banner6, alt: 'Banner 6' },
];

const deals = [
  { name: 'Phone deals', to: '/phone-deals', img: dealPhone },
  { name: 'Laptops deals', to: '/laptop-deals', img: dealLaptop },
  { name: 'Power Banks deals', to: '/powerbank-deals', img: dealPowerbank },
  { name: 'Head Phones deals', to: '/headphone-deals', img: dealHeadphone },
  { name: 'Speaker deals', to: '/speaker-deals', img: dealSpeaker },
  { name: 'Charger deals', to: '/charger-deals', img: dealCharger },
  { name: 'Smart Watch deals', to: '/smartwatch-deals', img: dealSmartwatch },
  { name: 'Flash Drives deals', to: '/flashdrive-deals', img: dealFlashdrive },
];

function Homepage() {
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      {/* Carousel Section */}
      <div className="relative w-full overflow-hidden rounded-lg shadow-lg">
        <div className="flex space-x-4 overflow-x-auto snap-x snap-mandatory scrollbar-hide p-4">
          {banners.map((banner, index) => (
            <img
              key={index}
              src={banner.src}
              alt={banner.alt}
              className="flex-shrink-0 w-full max-w-4xl h-64 object-cover rounded-lg snap-center"
              loading="lazy"
            />
          ))}
        </div>
      </div>

      {/* Deals Grid */}
      <main className="container mx-auto p-4 flex-grow">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 mt-6">
          {deals.map((deal) => (
            <Link
              key={deal.to}
              to={deal.to}
              className="block rounded-lg overflow-hidden shadow hover:shadow-lg transition-shadow duration-300"
            >
              <img
                src={deal.img}
                alt={deal.name}
                className="w-full h-40 object-cover"
                loading="lazy"
              />
              <p className="text-center mt-2 font-semibold text-yellow-600">{deal.name}</p>
            </Link>
          ))}
        </div>
      </main>
    </div>
  );
}

export default Homepage;
