import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getPhone, getSolePhone } from '../api/phoneApi.js';
import { getLaptop, getSoleLaptopHeader } from '../api/laptopApi.js';

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  // Search in phones
  let product = null;
  let category = 'phone';
  for (const phoneCategory of ['apple', 'samsung', 'tecno']) {
    product = getSolePhone(phoneCategory, id);
    if (product) break;
  }

  // If not found in phones, search in laptops
  if (!product) {
    category = 'laptop';
    for (const laptopCategory of ['hp', 'dell', 'lenovo']) {
      product = getSoleLaptopHeader(laptopCategory, id);
      if (product) break;
    }
  }

  if (!product) {
    return (
      <div className="container mx-auto p-4 text-center">
        <h2 className="text-2xl font-bold mb-4">Product not found</h2>
        <button
          onClick={() => navigate(-1)}
          className="px-4 py-2 bg-yellow-600 text-white rounded hover:bg-yellow-700"
        >
          Go Back
        </button>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4">
      <button
        onClick={() => navigate(-1)}
        className="mb-4 px-4 py-2 bg-yellow-600 text-white rounded hover:bg-yellow-700"
      >
        Back
      </button>
      <div className="flex flex-col md:flex-row gap-6">
        <img
          src={product.image}
          alt={product.name}
          className="w-full md:w-1/2 h-auto object-cover rounded"
          loading="lazy"
        />
        <div className="md:w-1/2">
          <h1 className="text-3xl font-bold mb-4">{product.name}</h1>
          <p className="text-xl text-yellow-600 font-semibold mb-4">{product.price}</p>
          <p className="mb-4">{product.details || product.description}</p>
          <button className="px-6 py-3 bg-yellow-600 text-white rounded hover:bg-yellow-700">
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
