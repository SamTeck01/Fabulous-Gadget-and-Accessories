import React from 'react'
import ReactDOM from 'react-dom'
import PhoneInfo from '../phone/phone-info'

function Modal({ open, soleTrending, onClose }) {
  if (!open) return null

  return ReactDOM.createPortal(
    <>
    <div
        className="fixed inset-0 bg-black bg-opacity-80 z-50 flex justify-center items-start pt-24"
        onClick={onClose}
      >
        <div
          className="relative bg-yellow-50 rounded-lg p-6 max-w-4xl w-full overflow-hidden shadow-lg"
          onClick={(e) => e.stopPropagation()}
        >
          <PhoneInfo soleTrending={soleTrending} />
          <button
            onClick={onClose}
            className="absolute top-2 right-2 text-yellow-600 hover:text-yellow-800"
            aria-label="Close modal"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      </div>
    </>,
    document.getElementById('portal')
  )
}

export default Modal
