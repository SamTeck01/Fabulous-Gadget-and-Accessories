import React from 'react';

const ProductCard = ({ product, onClick }) => {
  const { image, name, price } = product;
  return (
    <div
      className="rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300 cursor-pointer bg-white"
      onClick={onClick}
    >
      <img
        src={image}
        alt={name}
        className="w-full h-40 object-cover"
        loading="lazy"
      />
      <p className="text-center mt-2 font-semibold truncate text-gray-900">{name}</p>
      <span className="block text-center font-semibold text-yellow-600 text-lg mt-1">{price}</span>
    </div>
  );
};

export default ProductCard;
