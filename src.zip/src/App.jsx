import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Homepage from './pages/Homepage'
import PhoneDeals from './pages/PhoneDeals'
import LaptopDeals from './pages/LaptopDeals'
import ProductDetail from './pages/ProductDetail'
import Footer from './components/Footer'

function App() {
  return (
    <Router>
      <div className="min-h-screen flex flex-col">
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Homepage />} />
            <Route path="/phone-deals" element={<PhoneDeals />} />
            <Route path="/laptop-deals" element={<LaptopDeals />} />
            <Route path="/product/:id" element={<ProductDetail products={[]} />} />
            {/* Additional routes will be added here */}
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  )
}

export default App
